# Snewroof Operations Portal - Deployment Guide

## Table of Contents
- [Prerequisites](#prerequisites)
- [Environment Configuration](#environment-configuration)
- [Local Deployment](#local-deployment)
- [Docker Deployment](#docker-deployment)
- [Production Setup](#production-setup)
- [Monitoring & Maintenance](#monitoring--maintenance)
- [Troubleshooting](#troubleshooting)

## Prerequisites

- **Node.js** 18+ or **Bun** 1.3+
- **Docker** (for containerized deployment)
- **Git** (for version control)
- **Domain name** (for production)
- **SSL certificates** (for HTTPS)

## Environment Configuration

### 1. Copy Environment Template

```bash
cp .env.example .env
```

### 2. Configure Required Variables

Edit `.env` file:

```bash
# Database (SQLite default - no additional setup needed)
DATABASE_URL="file:./db/custom.db"

# NextAuth - REQUIRED
NEXTAUTH_URL="https://yourdomain.com"  # Update with your domain
NEXTAUTH_SECRET="generate-a-long-random-secret-min-32-chars"

# Environment
NODE_ENV="production"
```

### 3. Generate NEXTAUTH_SECRET

Generate a secure secret:

```bash
# Using OpenSSL
openssl rand -base64 32

# Or using Node
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# Or using Bun
bun -e "console.log(crypto.randomBytes(32).toString('base64'))"
```

## Local Deployment

### 1. Install Dependencies

```bash
bun install
```

### 2. Setup Database

```bash
# Push schema to database
bun run db:push

# (Optional) Seed with sample data
curl -X POST http://localhost:3000/api/seed
```

### 3. Start Development Server

```bash
# Main application
bun run dev

# In separate terminal - Website monitor
cd mini-services/website-monitor
bun run dev
```

### 4. Access Application

- Main App: http://localhost:3000
- Default Login:
  - Admin: admin@snewroof.com / admin123
  - Manager: manager@snewroof.com / manager123
  - Analyst: analyst@snewroof.com / analyst123

## Docker Deployment

### Quick Start

```bash
# Build and start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Step-by-Step Docker Deployment

#### 1. Prepare Environment File

```bash
# Create production .env file
cp .env.example .env.production

# Edit with production values
nano .env.production
```

#### 2. Build Docker Images

```bash
# Build main application
docker build -t snewroof-app:latest .

# Build website monitor
docker build -t snewroof-website-monitor:latest ./mini-services/website-monitor
```

#### 3. Run Containers

```bash
# Run with docker-compose
docker-compose -f docker-compose.yml up -d

# Or run individually
docker run -d \
  --name snewroof-app \
  -p 3000:3000 \
  --env-file .env.production \
  -v $(pwd)/db:/app/db \
  snewroof-app:latest

docker run -d \
  --name snewroof-website-monitor \
  -p 3001:3001 \
  snewroof-website-monitor:latest
```

#### 4. Verify Deployment

```bash
# Check container status
docker ps

# Check logs
docker logs snewroof-app

# Check health endpoint
curl http://localhost:3000/api/health
```

## Production Setup

### 1. Server Requirements

- **CPU**: 2 cores minimum
- **RAM**: 2GB minimum
- **Storage**: 20GB minimum
- **OS**: Ubuntu 20.04+ or similar

### 2. Server Setup (Ubuntu)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install Nginx (for reverse proxy)
sudo apt install nginx certbot python3-certbot-nginx -y
```

### 3. Deploy Application

```bash
# Clone repository
git clone <repository-url> /opt/snewroof
cd /opt/snewroof

# Configure environment
cp .env.example .env
nano .env  # Update with production values

# Create database directory
mkdir -p db logs

# Set proper permissions
sudo chown -R 1001:1001 db logs

# Start services
docker-compose up -d
```

### 4. Configure Nginx Reverse Proxy

Create `/etc/nginx/sites-available/snewroof`:

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    location /ws/ {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Enable site:

```bash
sudo ln -s /etc/nginx/sites-available/snewroof /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 5. Setup SSL Certificate

```bash
# Obtain certificate
sudo certbot --nginx -d yourdomain.com

# Auto-renewal (test)
sudo certbot renew --dry-run

# Certbot will configure Nginx automatically
```

### 6. Setup Firewall

```bash
# Configure UFW
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable
```

## Monitoring & Maintenance

### Health Checks

```bash
# Application health
curl http://localhost:3000/api/health

# Website monitor health
curl http://localhost:3001/health
```

### View Logs

```bash
# Docker logs
docker logs -f snewroof-app
docker logs -f snewroof-website-monitor

# Application logs
tail -f logs/app.log

# Database operations
# Check SQLite operations in dev server logs
```

### Backup Strategy

```bash
# Backup database
docker exec snewroof-app tar -czf - /app/db/ | gzip > backup-$(date +%Y%m%d).tar.gz

# Backup to remote (using rsync)
rsync -avz /opt/snewroof/ backup-server:/backups/snewroof/

# Automated backup script (cron)
# Add to crontab: 0 2 * * * /opt/snewroof/scripts/backup.sh
```

### Database Migration

```bash
# Run migrations
docker exec -it snewroof-app bun run db:migrate

# Reset database (CAUTION - destroys data)
docker exec -it snewroof-app bun run db:push --force-reset

# Reseed after reset
curl -X POST http://localhost:3000/api/seed
```

### Update Application

```bash
# Pull latest code
git pull origin main

# Rebuild and restart
docker-compose down
docker-compose build
docker-compose up -d

# Check status
docker ps
curl http://localhost:3000/api/health
```

## Troubleshooting

### Application Won't Start

```bash
# Check container status
docker ps -a

# Check logs
docker logs snewroof-app

# Common issues:
# - Port 3000 already in use: Check for other processes
# - Database locked: Check file permissions
# - Environment variables missing: Verify .env file
```

### Database Issues

```bash
# Check database file
ls -la db/custom.db

# Fix permissions
sudo chown 1001:1001 db/custom.db
sudo chmod 644 db/custom.db

# Reset database (last resort)
docker exec -it snewroof-app bun run db:push --force-reset
```

### Website Monitor Not Working

```bash
# Check service status
curl http://localhost:3001/health

# Check logs
docker logs snewroof-website-monitor

# Restart service
docker restart snewroof-website-monitor
```

### Performance Issues

```bash
# Check resource usage
docker stats

# Monitor disk space
df -h

# Clean up Docker resources
docker system prune -a

# Check database size
ls -lh db/custom.db
```

### SSL Certificate Issues

```bash
# Renew certificates
sudo certbot renew

# Check certificate status
sudo certbot certificates

# Force renewal
sudo certbot renew --force-renewal
```

## Security Checklist

- [ ] Change default passwords immediately
- [ ] Use strong NEXTAUTH_SECRET (32+ characters)
- [ ] Enable HTTPS with valid SSL certificate
- [ ] Configure firewall rules
- [ ] Regular security updates
- [ ] Monitor logs for suspicious activity
- [ ] Regular backups
- [ ] Disable unused services
- [ ] Use environment variables for secrets
- [ ] Never commit .env files

## Performance Optimization

1. **Database Optimization**
   - Use PostgreSQL for production (if needed)
   - Add indexes to frequently queried fields
   - Regular database maintenance

2. **Application Caching**
   - Enable response caching
   - Use Redis for distributed caching
   - Cache static assets

3. **Load Balancing**
   - Use multiple app instances
   - Configure Nginx load balancing
   - Scale based on traffic

4. **Monitoring**
   - Setup application monitoring
   - Configure alerting
   - Track performance metrics

## Support

For issues or questions:
- Check logs: `docker logs snewroof-app`
- Health check: `curl https://yourdomain.com/api/health`
- Documentation: `/home/z/my-project/README.md`

---

**Version**: 1.0.0
**Last Updated**: 2026

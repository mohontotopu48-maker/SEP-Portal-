import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(req: NextRequest) {
  const pathname = req.nextUrl.pathname

  // Allow these paths without authentication
  const publicPaths = ['/login', '/api/seed', '/api/health', '/api/test', '/api/auth']
  const isPublicPath = publicPaths.some(path => pathname.startsWith(path))

  // Allow NextAuth callbacks
  if (pathname.startsWith('/api/auth')) {
    return NextResponse.next()
  }

  // Allow public paths
  if (isPublicPath) {
    return NextResponse.next()
  }

  // Check for session token
  const token = req.cookies.get('next-auth.session-token') ||
                 req.cookies.get('__Secure-next-auth.session-token')

  // Redirect to login if not authenticated
  if (!token) {
    return NextResponse.redirect(new URL('/login', req.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
}

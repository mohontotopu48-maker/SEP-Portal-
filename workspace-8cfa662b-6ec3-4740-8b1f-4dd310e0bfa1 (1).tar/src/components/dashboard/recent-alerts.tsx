import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { AlertTriangle, Info, AlertCircle, Bell, Clock } from 'lucide-react'

interface AlertData {
  id: string
  type: 'website_down' | 'cost_due' | 'task_overdue' | 'ssl_expiry'
  severity: 'info' | 'warning' | 'critical'
  title: string
  message?: string
  isRead: boolean
  createdAt: string
}

interface RecentAlertsProps {
  alerts: AlertData[]
}

export function RecentAlerts({ alerts }: RecentAlertsProps) {
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-orange-600" />
      default:
        return <Info className="h-4 w-4 text-blue-600" />
    }
  }

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Critical</Badge>
      case 'warning':
        return <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">Warning</Badge>
      default:
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Info</Badge>
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'website_down':
        return 'Website'
      case 'cost_due':
        return 'Billing'
      case 'task_overdue':
        return 'Task'
      case 'ssl_expiry':
        return 'SSL'
      default:
        return 'System'
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle>Recent Alerts</CardTitle>
        {alerts.some(a => !a.isRead) && (
          <Badge variant="destructive" className="text-xs">
            {alerts.filter(a => !a.isRead).length} New
          </Badge>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-80 overflow-y-auto">
          {alerts.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              No alerts
            </p>
          ) : (
            alerts.map((alert) => (
              <div
                key={alert.id}
                className={cn(
                  'flex gap-3 p-3 rounded-lg border transition-colors',
                  !alert.isRead ? 'bg-muted/50 border-muted-foreground/20' : 'hover:bg-accent'
                )}
              >
                <div className="mt-0.5">
                  {getSeverityIcon(alert.severity)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-xs">
                      {getTypeLabel(alert.type)}
                    </Badge>
                    {getSeverityBadge(alert.severity)}
                  </div>
                  <p className="font-medium text-sm">{alert.title}</p>
                  {alert.message && (
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {alert.message}
                    </p>
                  )}
                  <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>{new Date(alert.createdAt).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}

function cn(...classes: (string | undefined | null | false)[]) {
  return classes.filter(Boolean).join(' ')
}

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { CheckCircle, XCircle, Clock } from 'lucide-react'

interface Website {
  id: string
  name: string
  url: string
  status: 'up' | 'down' | 'unknown'
  uptime: number
  lastChecked: string
}

interface WebsiteStatusProps {
  websites: Website[]
}

export function WebsiteStatus({ websites }: WebsiteStatusProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'up':
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'down':
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-yellow-600" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'up':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Online</Badge>
      case 'down':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Offline</Badge>
      default:
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Unknown</Badge>
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Website Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {websites.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              No websites configured
            </p>
          ) : (
            websites.map((site) => (
              <div
                key={site.id}
                className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent transition-colors"
              >
                <div className="flex items-center gap-3">
                  {getStatusIcon(site.status)}
                  <div>
                    <p className="font-medium text-sm">{site.name}</p>
                    <p className="text-xs text-muted-foreground">{site.url}</p>
                  </div>
                </div>
                <div className="text-right">
                  {getStatusBadge(site.status)}
                  <p className="text-xs text-muted-foreground mt-1">
                    {site.uptime.toFixed(1)}% uptime
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}

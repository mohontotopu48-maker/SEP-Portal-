'use client'

import { useEffect, useState } from 'react'
import { Sidebar } from '@/components/sidebar'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Textarea } from '@/components/ui/textarea'
import {
  Plus,
  MoreHorizontal,
  Pencil,
  Trash2,
  Download,
  Filter,
  TrendingUp,
  DollarSign,
  AlertCircle,
  Calendar,
  RefreshCw,
} from 'lucide-react'
import { toast } from 'sonner'
import { format } from 'date-fns'

interface Cost {
  id: string
  name: string
  description?: string
  category: string
  amount: number
  currency: string
  billingCycle?: string
  dueDate?: string
  renewalDate?: string
  isRecurring: boolean
  toolId?: string
  vendor?: string
  status: string
  reminderSent: boolean
  createdAt: string
  updatedAt: string
  tool?: {
    id: string
    name: string
  }
}

export default function CostsPage() {
  const [costs, setCosts] = useState<Cost[]>([])
  const [tools, setTools] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingCost, setEditingCost] = useState<Cost | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'monthly',
    amount: '',
    currency: 'USD',
    billingCycle: 'monthly',
    dueDate: '',
    renewalDate: '',
    isRecurring: false,
    toolId: '',
    vendor: '',
    status: 'active',
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [costsRes, toolsRes] = await Promise.all([
        fetch('/api/costs'),
        fetch('/api/tools'),
      ])

      if (costsRes.ok) {
        const costsData = await costsRes.json()
        setCosts(costsData)
      }

      if (toolsRes.ok) {
        const toolsData = await toolsRes.json()
        setTools(toolsData)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
      toast.error('Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const url = editingCost ? `/api/costs/${editingCost.id}` : '/api/costs'
      const method = editingCost ? 'PATCH' : 'POST'

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          amount: parseFloat(formData.amount),
          dueDate: formData.dueDate || null,
          renewalDate: formData.renewalDate || null,
          toolId: formData.toolId || null,
        }),
      })

      if (response.ok) {
        toast.success(editingCost ? 'Cost updated successfully' : 'Cost created successfully')
        setDialogOpen(false)
        resetForm()
        fetchData()
      } else {
        toast.error('Failed to save cost')
      }
    } catch (error) {
      console.error('Error saving cost:', error)
      toast.error('Failed to save cost')
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this cost?')) return

    try {
      const response = await fetch(`/api/costs/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        toast.success('Cost deleted successfully')
        fetchData()
      } else {
        toast.error('Failed to delete cost')
      }
    } catch (error) {
      console.error('Error deleting cost:', error)
      toast.error('Failed to delete cost')
    }
  }

  const handleEdit = (cost: Cost) => {
    setEditingCost(cost)
    setFormData({
      name: cost.name,
      description: cost.description || '',
      category: cost.category,
      amount: cost.amount.toString(),
      currency: cost.currency,
      billingCycle: cost.billingCycle || 'monthly',
      dueDate: cost.dueDate ? cost.dueDate.split('T')[0] : '',
      renewalDate: cost.renewalDate ? cost.renewalDate.split('T')[0] : '',
      isRecurring: cost.isRecurring,
      toolId: cost.toolId || '',
      vendor: cost.vendor || '',
      status: cost.status,
    })
    setDialogOpen(true)
  }

  const resetForm = () => {
    setEditingCost(null)
    setFormData({
      name: '',
      description: '',
      category: 'monthly',
      amount: '',
      currency: 'USD',
      billingCycle: 'monthly',
      dueDate: '',
      renewalDate: '',
      isRecurring: false,
      toolId: '',
      vendor: '',
      status: 'active',
    })
  }

  const getCategoryBadge = (category: string) => {
    const styles: Record<string, string> = {
      monthly: 'bg-blue-50 text-blue-700 border-blue-200',
      subscription: 'bg-purple-50 text-purple-700 border-purple-200',
      license: 'bg-green-50 text-green-700 border-green-200',
      onetime: 'bg-orange-50 text-orange-700 border-orange-200',
    }
    return <Badge variant="outline" className={styles[category] || ''}>{category}</Badge>
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      active: 'bg-green-50 text-green-700 border-green-200',
      paid: 'bg-blue-50 text-blue-700 border-blue-200',
      cancelled: 'bg-gray-50 text-gray-700 border-gray-200',
    }
    return <Badge variant="outline" className={styles[status] || ''}>{status}</Badge>
  }

  const calculateTotalMonthly = () => {
    return costs
      .filter((c) => c.status === 'active')
      .reduce((sum, cost) => {
        if (cost.billingCycle === 'yearly') {
          return sum + cost.amount / 12
        }
        return sum + cost.amount
      }, 0)
  }

  const totalMonthly = calculateTotalMonthly()
  const totalYearly = totalMonthly * 12

  if (loading) {
    return (
      <div className="flex min-h-screen">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="flex items-center justify-center h-[calc(100vh-3rem)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading costs...</p>
            </div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold">Cost & Billing Manager</h1>
              <p className="text-muted-foreground mt-1">
                Track and manage all your operational costs
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={fetchData}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => { resetForm(); }}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Cost
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingCost ? 'Edit Cost' : 'Add New Cost'}
                    </DialogTitle>
                    <DialogDescription>
                      {editingCost
                        ? 'Update the cost information below.'
                        : 'Add a new cost entry to track your operational expenses.'}
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Cost Name *</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) =>
                              setFormData({ ...formData, name: e.target.value })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="category">Category *</Label>
                          <Select
                            value={formData.category}
                            onValueChange={(value) =>
                              setFormData({ ...formData, category: value })
                            }
                          >
                            <SelectTrigger id="category">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="subscription">Subscription</SelectItem>
                              <SelectItem value="license">License</SelectItem>
                              <SelectItem value="onetime">One-time</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          value={formData.description}
                          onChange={(e) =>
                            setFormData({ ...formData, description: e.target.value })
                          }
                          rows={2}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="amount">Amount *</Label>
                          <Input
                            id="amount"
                            type="number"
                            step="0.01"
                            value={formData.amount}
                            onChange={(e) =>
                              setFormData({ ...formData, amount: e.target.value })
                            }
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="currency">Currency</Label>
                          <Select
                            value={formData.currency}
                            onValueChange={(value) =>
                              setFormData({ ...formData, currency: value })
                            }
                          >
                            <SelectTrigger id="currency">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="USD">USD</SelectItem>
                              <SelectItem value="EUR">EUR</SelectItem>
                              <SelectItem value="GBP">GBP</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="billingCycle">Billing Cycle</Label>
                          <Select
                            value={formData.billingCycle}
                            onValueChange={(value) =>
                              setFormData({ ...formData, billingCycle: value })
                            }
                          >
                            <SelectTrigger id="billingCycle">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="yearly">Yearly</SelectItem>
                              <SelectItem value="quarterly">Quarterly</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="dueDate">Due Date</Label>
                          <Input
                            id="dueDate"
                            type="date"
                            value={formData.dueDate}
                            onChange={(e) =>
                              setFormData({ ...formData, dueDate: e.target.value })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="renewalDate">Renewal Date</Label>
                          <Input
                            id="renewalDate"
                            type="date"
                            value={formData.renewalDate}
                            onChange={(e) =>
                              setFormData({ ...formData, renewalDate: e.target.value })
                            }
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="toolId">Associated Tool</Label>
                          <Select
                            value={formData.toolId}
                            onValueChange={(value) =>
                              setFormData({ ...formData, toolId: value })
                            }
                          >
                            <SelectTrigger id="toolId">
                              <SelectValue placeholder="Select a tool (optional)" />
                            </SelectTrigger>
                            <SelectContent>
                              {tools.map((tool) => (
                                <SelectItem key={tool.id} value={tool.id}>
                                  {tool.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="vendor">Vendor</Label>
                          <Input
                            id="vendor"
                            value={formData.vendor}
                            onChange={(e) =>
                              setFormData({ ...formData, vendor: e.target.value })
                            }
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="isRecurring"
                            checked={formData.isRecurring}
                            onChange={(e) =>
                              setFormData({ ...formData, isRecurring: e.target.checked })
                            }
                            className="h-4 w-4"
                          />
                          <Label htmlFor="isRecurring">Recurring Payment</Label>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="status">Status</Label>
                          <Select
                            value={formData.status}
                            onValueChange={(value) =>
                              setFormData({ ...formData, status: value })
                            }
                          >
                            <SelectTrigger id="status">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="paid">Paid</SelectItem>
                              <SelectItem value="cancelled">Cancelled</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">
                        {editingCost ? 'Update' : 'Create'} Cost
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Monthly</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  ${totalMonthly.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Total active monthly costs
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Yearly</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  ${totalYearly.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Projected annual cost
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Costs</CardTitle>
                <Filter className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{costs.length}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {costs.filter((c) => c.status === 'active').length} active costs
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Costs Table */}
          <Card>
            <CardHeader>
              <CardTitle>All Costs</CardTitle>
              <CardDescription>
                Manage and track all your operational expenses
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Billing Cycle</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Vendor</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {costs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                          No costs found. Click "Add Cost" to create one.
                        </TableCell>
                      </TableRow>
                    ) : (
                      costs.map((cost) => (
                        <TableRow key={cost.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{cost.name}</p>
                              {cost.description && (
                                <p className="text-sm text-muted-foreground line-clamp-1">
                                  {cost.description}
                                </p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{getCategoryBadge(cost.category)}</TableCell>
                          <TableCell>
                            <span className="font-medium">
                              ${cost.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </span>
                            <span className="text-muted-foreground ml-1">{cost.currency}</span>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span className="capitalize">{cost.billingCycle}</span>
                              {cost.isRecurring && (
                                <Badge variant="outline" className="text-xs">
                                  <RefreshCw className="h-3 w-3 mr-1" />
                                  Recurring
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            {cost.dueDate ? (
                              <div className="flex items-center gap-2">
                                <Calendar className="h-3 w-3 text-muted-foreground" />
                                <span className="text-sm">
                                  {format(new Date(cost.dueDate), 'MMM d, yyyy')}
                                </span>
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>{cost.vendor || '-'}</TableCell>
                          <TableCell>{getStatusBadge(cost.status)}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => handleEdit(cost)}>
                                  <Pencil className="h-4 w-4 mr-2" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="text-red-600"
                                  onClick={() => handleDelete(cost.id)}
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

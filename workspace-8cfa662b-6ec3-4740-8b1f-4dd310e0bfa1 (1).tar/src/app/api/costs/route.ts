import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const costs = await db.cost.findMany({
      orderBy: {
        createdAt: 'desc'
      },
      include: {
        tool: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    return NextResponse.json(costs)
  } catch (error) {
    console.error('Error fetching costs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch costs' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      name,
      description,
      category,
      amount,
      currency,
      billingCycle,
      dueDate,
      renewalDate,
      isRecurring,
      toolId,
      vendor,
      status
    } = body

    const cost = await db.cost.create({
      data: {
        name,
        description,
        category,
        amount: parseFloat(amount),
        currency,
        billingCycle,
        dueDate: dueDate ? new Date(dueDate) : null,
        renewalDate: renewalDate ? new Date(renewalDate) : null,
        isRecurring,
        toolId: toolId || null,
        vendor,
        status
      },
      include: {
        tool: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    return NextResponse.json(cost, { status: 201 })
  } catch (error) {
    console.error('Error creating cost:', error)
    return NextResponse.json(
      { error: 'Failed to create cost' },
      { status: 500 }
    )
  }
}

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const toolId = searchParams.get('toolId')

    const where = toolId ? { toolId } : {}

    const apiKeys = await db.apiKey.findMany({
      where,
      orderBy: {
        createdAt: 'desc'
      },
      include: {
        tool: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    return NextResponse.json(apiKeys)
  } catch (error) {
    console.error('Error fetching API keys:', error)
    return NextResponse.json(
      { error: 'Failed to fetch API keys' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, keyValue, toolId } = body

    const apiKey = await db.apiKey.create({
      data: {
        name,
        keyValue,
        toolId,
        isActive: true
      },
      include: {
        tool: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    return NextResponse.json(apiKey, { status: 201 })
  } catch (error) {
    console.error('Error creating API key:', error)
    return NextResponse.json(
      { error: 'Failed to create API key' },
      { status: 500 }
    )
  }
}

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '10')

    const alerts = await db.alert.findMany({
      orderBy: {
        createdAt: 'desc'
      },
      take: limit
    })

    return NextResponse.json(alerts)
  } catch (error) {
    console.error('Error fetching alerts:', error)
    return NextResponse.json(
      { error: 'Failed to fetch alerts' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json()
    const { ids, isRead, isResolved } = body

    await db.alert.updateMany({
      where: {
        id: {
          in: ids
        }
      },
      data: {
        ...(isRead !== undefined && { isRead }),
        ...(isResolved !== undefined && {
          isResolved,
          resolvedAt: isResolved ? new Date() : null
        })
      }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error updating alerts:', error)
    return NextResponse.json(
      { error: 'Failed to update alerts' },
      { status: 500 }
    )
  }
}

import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { SessionProvider } from "@/components/providers/session-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Snewroof Operations & Monitoring Portal",
  description: "Centralized system to monitor tools, costs, website health, projects, and team performance.",
  keywords: ["Snewroof", "Operations", "Monitoring", "Dashboard", "Next.js", "TypeScript"],
  authors: [{ name: "Topon Mohonto" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Snewroof Operations Portal",
    description: "Monitor tools, costs, website health, and team performance",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <SessionProvider>
          {children}
        </SessionProvider>
        <Toaster />
      </body>
    </html>
  );
}

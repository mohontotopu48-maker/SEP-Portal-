# Snewroof Operations & Monitoring Portal

> A comprehensive, production-ready operations and monitoring portal built with Next.js 16, TypeScript, and Prisma.

![Production Ready](https://img.shields.io/badge/status-production%20ready-success)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)

---

## 🚀 Quick Start

### Docker Deployment (Recommended)

```bash
# Clone and configure
git clone <repository-url>
cd snewroof-portal
cp .env.example .env

# Edit .env with your configuration
nano .env

# Start all services
docker-compose up -d

# Access application
# http://localhost:3000 (development)
# http://your-domain.com (production)
```

### Manual Deployment

```bash
# Install dependencies
bun install

# Setup database
bun run db:push

# Seed sample data (optional)
bun run scripts/seed-db.ts

# Start development server
bun run dev
```

### Default Login Credentials

⚠️ **Important**: Change these passwords immediately after first login!

| Role    | Email                  | Password   |
|----------|------------------------|------------|
| Admin    | admin@snewroof.com    | admin123   |
| Manager  | manager@snewroof.com  | manager123 |
| Analyst  | analyst@snewroof.com  | analyst123 |

---

## 📚 Documentation

- **[Production README](./PRODUCTION-README.md)** - Complete production deployment guide
- **[Deployment Guide](./DEPLOYMENT.md)** - Step-by-step deployment instructions
- **[API Documentation](./docs/API.md)** - API endpoints reference
- **[Environment Variables](./.env.example)** - Configuration template

---

## ✨ Features

### Core Functionality

- **🔐 Authentication System**
  - NextAuth.js v4 with secure JWT sessions
  - Password hashing with bcryptjs
  - Role-based access control (RBAC)
  - User activation/deactivation

- **📊 Dashboard**
  - Real-time metrics and KPIs
  - Website status monitoring
  - Cost tracking and analysis
  - Task and alert summaries
  - Responsive design (mobile-first)

- **💰 Cost & Billing Manager**
  - Full CRUD operations
  - Monthly/yearly calculations
  - Vendor and category tracking
  - Due date and renewal management
  - Recurring payment indicators

- **🔧 Tools & API Manager**
  - Tool inventory management
  - Secure API key storage
  - Usage tracking with limits
  - Expiry date monitoring
  - Owner assignment

- **🌐 Website & Server Monitor**
  - Real-time uptime monitoring
  - SSL certificate tracking
  - Response time monitoring
  - Automatic health checks
  - Alert generation for downtime

- **👥 Team & Role Management**
  - Role-based permissions
  - User activation/deactivation
  - Activity audit logging

- **🔔 Alert System**
  - Multi-type alerts
  - Severity levels
  - Read/unread tracking
  - Resolution management

---

## 🏗️ Technology Stack

```
Frontend:
├── Next.js 16 (App Router)
├── React 19
├── TypeScript 5
├── Tailwind CSS 4
├── shadcn/ui Components
└── Lucide Icons

Backend:
├── Next.js API Routes
├── Prisma ORM
├── SQLite (default)
├── NextAuth.js v4
├── bcryptjs
└── z-ai-web-dev-sdk

Infrastructure:
├── Docker & Docker Compose
├── Nginx (reverse proxy)
├── Health checks
└── SSL/TLS support
```

---

## 📂 Project Structure

```
/home/z/my-project/
├── src/
│   ├── app/                      # Next.js App Router
│   │   ├── api/                 # API routes
│   │   ├── dashboard/            # Dashboard pages
│   │   ├── costs/                # Cost management
│   │   ├── tools/                # Tools management
│   │   ├── websites/             # Website monitoring
│   │   ├── login/                # Authentication
│   │   └── ...
│   ├── components/               # React components
│   │   ├── dashboard/
│   │   ├── ui/                  # shadcn/ui
│   │   ├── providers/
│   │   └── sidebar.tsx
│   ├── lib/                     # Utilities
│   │   ├── auth/
│   │   ├── db.ts
│   │   └── utils.ts
│   ├── middleware.ts             # Route protection
│   └── types/                   # TypeScript types
├── prisma/
│   └── schema.prisma             # Database schema
├── mini-services/               # Microservices
│   └── website-monitor/          # Monitoring service
├── scripts/                    # Utility scripts
├── Dockerfile                  # Container config
├── docker-compose.yml           # Service orchestration
├── .env.example               # Environment template
└── package.json                # Dependencies
```

---

## 🔒 Security

### Implemented Measures

- ✅ NextAuth.js with secure JWT sessions
- ✅ Password hashing (bcryptjs, salt rounds: 10)
- ✅ Role-based access control (RBAC)
- ✅ Route protection via middleware
- ✅ SQL injection prevention (Prisma ORM)
- ✅ HTTPS enforcement
- ✅ Secure session handling
- ✅ Activity audit logging

### Security Checklist

- [ ] Change all default passwords
- [ ] Set strong NEXTAUTH_SECRET
- [ ] Configure HTTPS
- [ ] Enable firewall
- [ ] Set up backups
- [ ] Disable debug mode

See [Production README](./PRODUCTION-README.md) for details.

---

## 🚢 Deployment

### Options

1. **Docker (Recommended)**
   ```bash
   docker-compose up -d
   ```

2. **Manual**
   ```bash
   bun install
   bun run build
   bun start
   ```

3. **Cloud Platforms**
   - Vercel
   - Railway
   - DigitalOcean App Platform
   - AWS ECS
   - Google Cloud Run

### Health Check

```bash
curl http://localhost:3000/api/health
```

Response:
```json
{
  "status": "healthy",
  "services": {
    "database": "healthy",
    "api": "healthy"
  }
}
```

See [Deployment Guide](./DEPLOYMENT.md) for detailed instructions.

---

## 📊 Monitoring

### Endpoints

- **Main App**: `http://localhost:3000`
- **Health Check**: `http://localhost:3000/api/health`
- **Website Monitor**: `http://localhost:3001/health`

### Logs

```bash
# Docker logs
docker logs -f snewroof-app
docker logs -f snewroof-website-monitor

# Application logs
tail -f logs/app.log
```

---

## 🛠️ Maintenance

### Database Operations

```bash
# Backup
cp db/custom.db backups/custom-$(date +%Y%m%d).db

# Reset (CAUTION)
bun run db:push --force-reset

# Re-seed
bun run scripts/seed-db.ts
```

### Updates

```bash
# Pull latest
git pull origin main

# Rebuild
docker-compose down
docker-compose build
docker-compose up -d
```

---

## 🐛 Troubleshooting

### Common Issues

**Authentication failed**
```bash
# Check environment variables
cat .env | grep NEXTAUTH

# Reset session (clear browser cookies)
```

**Database locked**
```bash
# Check permissions
ls -la db/custom.db

# Reset database
bun run db:push --force-reset
```

**Service not responding**
```bash
# Check container status
docker ps

# View logs
docker logs snewroof-app
```

See [Production README](./PRODUCTION-README.md) for more troubleshooting.

---

## 📈 Performance

### Optimization Tips

1. Use PostgreSQL for production
2. Enable response caching
3. Implement CDN for static assets
4. Load balance multiple instances
5. Monitor performance metrics
6. Regular database maintenance

---

## 🤝 Development

### Setup

```bash
# Install dependencies
bun install

# Setup database
bun run db:push

# Start dev server
bun run dev
```

### Scripts

```bash
bun run dev          # Start development server
bun run build        # Build for production
bun run start        # Start production server
bun run lint         # Run ESLint
bun run db:push      # Push schema to database
bun run db:generate  # Generate Prisma client
```

---

## 📝 License

Proprietary - All rights reserved Snewroof

---

## 📞 Support

- **Documentation**: [Production README](./PRODUCTION-README.md) | [Deployment Guide](./DEPLOYMENT.md)
- **Health Check**: `curl http://your-domain.com/api/health`
- **Support**: Contact support team

---

**Version**: 1.0.0 Production Ready  
**Status**: ✅ Ready for Deployment  
**Last Updated**: February 2026  
**Maintained By**: Topon Mohonto
